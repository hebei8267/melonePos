/**
 * Internals for JDBC batching support.
 */
package org.hibernate.engine.jdbc.batch.internal;
