/**
 * Defines contracts for JDBC batching support.
 */
package org.hibernate.engine.jdbc.batch.spi;
