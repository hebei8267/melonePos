/**
 * Internals for accessing JDBC Connections
 */
package org.hibernate.engine.jdbc.connections.internal;
