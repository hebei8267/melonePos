/**
 * Defines contracts for JDBC REF_CURSOR support.
 */
package org.hibernate.engine.jdbc.cursor.spi;
