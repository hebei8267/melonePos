/**
 * Internal support for Dialect resolution (from JDBC metadata) and Dialect building.
 */
package org.hibernate.engine.jdbc.dialect.internal;
