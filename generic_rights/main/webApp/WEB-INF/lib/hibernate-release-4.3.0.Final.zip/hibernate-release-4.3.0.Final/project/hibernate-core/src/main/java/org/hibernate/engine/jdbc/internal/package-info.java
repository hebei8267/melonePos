/**
 * Internals for supporting various aspects of JDBC interaction
 */
package org.hibernate.engine.jdbc.internal;
