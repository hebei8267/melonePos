/**
 * Internal contracts defining the JNDI support within Hibernate
 */
package org.hibernate.engine.jndi.internal;
