/**
 * Support for JNDI within Hibernate
 */
package org.hibernate.engine.jndi;
