/**
 * The SPI contracts for Hibernate JNDI support
 */
package org.hibernate.engine.jndi.spi;
