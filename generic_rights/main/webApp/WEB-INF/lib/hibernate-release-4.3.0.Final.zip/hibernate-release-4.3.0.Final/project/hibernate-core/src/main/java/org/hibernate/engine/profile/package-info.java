/**
 * Models the fetch profiles defined by the application
 */
package org.hibernate.engine.profile;
