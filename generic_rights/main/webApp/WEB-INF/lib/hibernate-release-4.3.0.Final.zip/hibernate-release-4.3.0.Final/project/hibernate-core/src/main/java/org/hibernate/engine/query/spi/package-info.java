/**
 * Defines support for query plans and stored metadata about queries
 */
package org.hibernate.engine.query.spi;
